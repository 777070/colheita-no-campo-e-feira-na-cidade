// 🌾 Projeto p5.js: Do Campo à Cidade – Caminhos da Colheita com Emojis
// Objetivo: Coletar alimentos no campo (representados por emojis), atravessar a estrada e entregar na feira.
// O código utiliza funções, variáveis, estruturas de repetição e condição para criar interações dinâmicas.

let estado = "campo";
let alimentos = [];
let personagem;
let produtos = 0;
let emojiAlimentos = [
  "🍎", "🥕", "🌽", "🍅", "🥦", "🍓", "🍑", "🍍", "🍉", "🍒",
  "🍆", "🥬", "🥔", "🍠", "🌶️", "🍋", "🍇", "🍊", "🥭", "🍏",
  "🫐", "🧅", "🥑", "🫒", "🍤", "🌰", "🥖", "🧀", "🫑", "🍗", "🥩"
];
let campoFundo;
let estradaFundo;

function preload() {
  // Pré-carrega imagem de fundo do campo
  campoFundo = loadImage('fazenda.jpg');
  estradaFundo = loadImage('estrada.jpg');
  feiraFundo = loadImage('feira.jpg');
}

function setup() {
  createCanvas(600, 400);
  textAlign(CENTER, CENTER);
  textSize(24);
  personagem = createVector(300, 350);

  // Criando alimentos com posições aleatórias e emojis
  for (let i = 0; i < emojiAlimentos.length; i++) {
    alimentos.push({ pos: createVector(random(50, 550), random(100, 300)), emoji: emojiAlimentos[i] });
  }
}

function draw() {
  background(220);
  textSize(16);
  fill(0);

  if (estado === "campo") {
    mostrarCampo();
  } else if (estado === "estrada") {
    mostrarEstrada();
  } else if (estado === "feira") {
    mostrarFeira();
  }
}

function mostrarCampo() {
  image(campoFundo, 0, 0, width, height);

  // Título do projeto
  fill(255);
  textSize(40);
  text("🏘️ Do Campo à Cidade 🏙️", width / 2, 40);

  textSize(16);
  fill(255);
  text("🌿 Bem-vindo ao campo! Clique nos alimentos para coletá-los.", width / 2, 70);
  text("Coleta: " + produtos + "/30", width / 2, 385);

  // Cesta (representado por emoji 🧺)
  textSize(50);
  text("🧺", personagem.x, personagem.y);

  // Alimentos (emojis)
  for (let i = 0; i < alimentos.length; i++) {
    text(alimentos[i].emoji, alimentos[i].pos.x, alimentos[i].pos.y);
  }

  // Emoji de mão acompanhando o mouse
  textSize(35);
  text("🖐️", mouseX, mouseY);

  if (produtos >= 30) {
    estado = "estrada";
    personagem.x = 5;
    personagem.y = height / 2;
  }
}

function mostrarEstrada() {
  image(estradaFundo, 0, 0, width, height);
  
  textSize(40);
  text("➡️ A caminho da cidade! ➡️", width/ 2, 40);
  textSize(16);
  text("Use a seta  para levar a colheita até a feira.", width / 2, 70);
  textSize(50);
  text("🧑‍🌾🧺", personagem.x, personagem.y);

  if (keyIsDown(RIGHT_ARROW)) {
    personagem.x += 3;
  }

  if (personagem.x > width) {
    estado = "feira";
  }
}

function mostrarFeira() {
  image(feiraFundo, 0, 0, width, height);
  fill("white");
  rect(0, 0, 600, 125);
  fill("rgb(0,0,0)");
  textSize(35);
  text("🧑‍🌾Chegamos à feira!🧺", width / 2, height / 10);
  text("Obrigado por ajudar na colheita!", width / 2, height / 5);
  
}

function mousePressed() {
  if (estado === "campo") {
    for (let i = alimentos.length - 1; i >= 0; i--) {
      let d = dist(mouseX, mouseY, alimentos[i].pos.x, alimentos[i].pos.y);
      if (d < 20) {
        alimentos.splice(i, 1);
        produtos++;
      }
    }
  }
}

